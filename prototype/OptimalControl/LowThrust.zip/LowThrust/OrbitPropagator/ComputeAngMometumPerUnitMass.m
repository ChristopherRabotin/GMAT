

% inputs for Earth
 radius = 6378.1363;
 omega  = 2*pi/(86400)

% inputs for Jupiter
% radius = 71492;
% omega  = 2*pi/(9.925*3600)
% 
% % inputs for Sun
% radius = 695990;
% omega  = 2*pi/(28*86400)

%  Method 2 
H = 2/5*radius^2*omega

