

mu        = 398600.4415;
Re        = 6378.1363;
DU        = Re;
TU        = sqrt(DU^3/mu)
MU        = 1; 
FU        = MU*DU/TU^2