close all
clear mex
clear classes
clear all
clc; clearvars; 