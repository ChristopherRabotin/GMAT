classdef FuelTank < handle
    %UNTITLED4 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        FuelMass = 500;
    end
    
    methods
    end
    
end

