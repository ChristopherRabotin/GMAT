classdef Collocate < handle
    %UNTITLED6 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (SetAccess = 'protected')
        Trajectory
        Optimimizer
    end
    
    methods
    end
    
end

