function OrbitRaisingPlotFunction(traj)

stateArray = traj.phaseList{1}.DecVector.GetStateArray();
stateArray = stateArray.x;
controlArray = traj.phaseList{1}.DecVector.GetControlArray(); 
controlArray = controlArray.x;

x  = stateArray(:,1);
y  = stateArray(:,2);
plot(x,y);
drawnow;
%pause
return

