function [obj] = BrachistichronePointFunction(obj)

obj.costFunction  = obj.finalTime*100;