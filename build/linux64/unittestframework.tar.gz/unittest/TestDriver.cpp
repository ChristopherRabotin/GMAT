//$Id$
//------------------------------------------------------------------------------
//                           GmatConsole driver
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool.
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Author: Darrel J. Conway
// Created: 2003/08/28
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under contract
// number S-67573-G
//
/**
 * Program entry point for GmatConsole.
 */
//------------------------------------------------------------------------------

#include "TestDriver.hpp"

#include <fstream>

#include "BaseException.hpp"
#include "ConsoleAppException.hpp"
#include "ConsoleMessageReceiver.hpp"
#include "Moderator.hpp"
#include "StringUtil.hpp"

// Infrastructure
#include "GmatRunner.hpp"
#include "BuildCoreGmatObjects.hpp"
#include "MessageInterface.hpp"

// Specific classes used in the tests
#include "DataFileTester.hpp"

// Classes needed to configure the test cases
#include "SolarSystem.hpp"
#include "EopFile.hpp"


//#define DEBUG_CONSOLE

#ifdef DEBUG_CONSOLE
#include <unistd.h>
#endif


/**
 * The program entry point.
 * 
 * @param <argc> The count of the input arguments.
 * @param <argv> The input arguments.
 * 
 * @return 0 on success.
 */
//------------------------------------------------------------------------------
int main(int argc, char *argv[])
{
   try
   {
      std::string msg = "General Mission Analysis Tool\nConsole Based Version\n";

      msg += "Build Date: ";
      msg += __DATE__;
      msg += "  ";
      msg += __TIME__;
      
      std::cout << "\n********************************************\n"
                << "***  GMAT Unit Test Application\n"
                << "********************************************\n\n"
                << msg << "\n\n"
                << std::endl;
      
      bool        testMode = true;
      
      // Set the message receiver and moderator pointers here
      Moderator *mod = Moderator::Instance();
      mod->Initialize("gmat_startup_file.txt");

      std::cout << "Setting up the log" << std::endl;
      ConsoleMessageReceiver *theMessageReceiver = ConsoleMessageReceiver::Instance();
      theMessageReceiver->SetLogFile("../output/UnitTestLog.txt");
      MessageInterface::SetMessageReceiver(theMessageReceiver);

      if (argc > 1)
      {
         std::string arg("");

         arg = argv[1];
         if (arg != "--test")
            testMode = false;

         if ((testMode) && (argc > 2))
         {
            // Build the list of tests to run
         }

         arg = "";
      }

      if (testMode)
      {
         std::cout << "Setting globals" << std::endl;
         SetGmatGlobals();
         std::cout << "Calling tests\n" << std::endl;
         bool testResult = RunUnitTests();
         std::cout << "\n\nUnit tests "
                   << (testResult ? "passed!\n" : "failed.\n")
                   << std::endl;
      }
      else // Run GMAT in console mode
      {
         if (!RunGmatConsole(argc, argv))
            return -1;
      }
   }
   catch (BaseException &ex)
   {
      std::cout << ex.GetFullMessage() << std::endl;
      exit(0);
   }
   
   return 0;
}

/**
 * DataFile tester
 */
bool TestDataFile(SolarSystem *ss, ObjectArray *csSet)
{
   std::cout << "Testing DataFile: Creating the tester" << std::endl;
   DataFileTester dt;
   std::cout << "Testing DataFile: Calling into the class" << std::endl;
   return dt.RunTests(ss, csSet);
}


/**
 * The list of unit tests goes here
 *
 * @param runList A list of specific test to run, NULL to run all
 *
 * @return true if all tests succeed, false if there is a failure
 */
//------------------------------------------------------------------------------
bool RunUnitTests(StringArray *runlist)
{
   bool retval = true;

   StringArray testList;
   testList.push_back("All");

   if (runlist == NULL)
      runlist = &testList;

   SolarSystem *ss = BuildSolarSystem();
   ObjectArray *csSet = BuildCoordinateSystems(ss);

   // Here are the specific tests
   for (StringArray::iterator testToRun = runlist->begin();
        testToRun != runlist->end(); ++testToRun)
   {
      bool testResult = true;

      #ifdef ShowDefaultCSPointers      
         for (UnsignedInt i = 0; i < csSet->size(); ++i)
            MessageInterface::ShowMessage("   %s @ %p\n",
                  csSet->at(i)->GetName().c_str(), csSet->at(i));
      #endif

      if ((*testToRun == "All") || (*testToRun == "DataFile"))
      {
         testResult = TestDataFile(ss, csSet);
         std::cout << (testResult ? "Passed!\n" : "Failed!\n");

         if (testResult == false)
            retval = false;
      }
   }

   return retval;
}
