//$Id$
//------------------------------------------------------------------------------
//                           SignalTester
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Feb 3, 2014
/**
 * 
 */
//------------------------------------------------------------------------------

#include "SignalTester.hpp"

// Specific classes used in the tests
#include "PhysicalSignal.hpp"
#include "ProgressReporter.hpp"

// Classes needed to configure the test cases
#include "Spacecraft.hpp"
#include "GroundStation.hpp"
#include "MessageInterface.hpp"


SignalTester::SignalTester()
{
}

SignalTester::~SignalTester()
{
}

bool SignalTester::RunTests(SolarSystem *ss, ObjectArray *globals)
{
   bool testResult = true;

   MessageInterface::ShowMessage("\nRunning GeometricSignal tests\n");
   CelestialBody *earth = ss->GetBody("Earth");

   // Signals should all process via SignalBase interfaces
   SignalBase *sb = new PhysicalSignal("");

   ProgressReporter *reporter = new ProgressReporter(
         "Unit Tests for the GeometricSignal class\nTesting the reporter\n"
         "**************************************************************",
         "../output/SignalClassTester.txt");
   sb->SetProgressReporter(reporter);
   sb->UsesLighttime(false);
   reporter->SetLogLevel("Everything");
   reporter->SetLogLevel("Verbose");

   reporter->Initialize();

   if (sb)
   {
      sb->SetSolarSystem(ss);

      MessageInterface::ShowMessage("\nSat-Sat tests\n");
      MessageInterface::ShowMessage("     Setting Participants\n");
      CoordinateSystem *j2keq = ((CoordinateSystem*)(globals->at(0)));
      CoordinateSystem *ef = ((CoordinateSystem*)(globals->at(2)));

      Spacecraft *sat   = new Spacecraft("GeometricSat");
      sat->SetSolarSystem(ss);
      sat->SetJ2000Body(earth);
      sat->SetInternalCoordSystem(j2keq);
      sat->SetRefObject(j2keq, j2keq->GetType(), j2keq->GetName());
      sat->SetRefObject(ef, ef->GetType(), ef->GetName());
      sat->Initialize();

      Spacecraft *sat2   = new Spacecraft("GeometricSat2");
      sat2->SetSolarSystem(ss);
      sat2->SetJ2000Body(earth);
      sat2->SetInternalCoordSystem(j2keq);
      sat2->SetRefObject(j2keq, j2keq->GetType(), j2keq->GetName());
      sat2->SetRefObject(ef, ef->GetType(), ef->GetName());
      sat2->SetRealParameter("X", sat->GetRealParameter("X") + 300);
      sat2->SetRealParameter("VX", sat->GetRealParameter("VX") + 0.5);
      sat2->Initialize();

      if (sb->SetTransmitParticipantName("GeometricSat") == false)
      {
         MessageInterface::ShowMessage("Failed to set the name of the "
               "transmit participant\n");
         testResult = false;
      }
      if (sb->SetReceiveParticipantName("GeometricSat2") == false)
      {
         MessageInterface::ShowMessage("Failed to set the name of the "
               "transmit participant\n");
         testResult = false;
      }

      if (sb->SetRefObject(sat, sat->GetType(), sat->GetName()) == false)
      {
         MessageInterface::ShowMessage("Failed to set the transmit "
               "participant\n");
         testResult = false;
      }

      if (sb->SetRefObject(sat2, sat2->GetType(), sat2->GetName()) == false)
      {
         MessageInterface::ShowMessage("Failed to set the receive "
               "participant\n");
         testResult = false;
      }

      MessageInterface::ShowMessage("   Initializing\n");
      if (sb->Initialize())
      {
         MessageInterface::ShowMessage("   Modeling\n");
         if (sb->ModelSignal(21545.0) == false)
         {
            MessageInterface::ShowMessage("Geometric signal modeling failed\n");
            testResult = false;
         }
      }
      else
      {
         MessageInterface::ShowMessage("Geometric signal initialization "
               "failed\n");
         testResult = false;
      }

      MessageInterface::ShowMessage("\nSat-Ground tests\n");
      GroundStation *gs = new GroundStation("Groundstat");
      gs->SetSolarSystem(ss);
      gs->SetInternalCoordSystem(j2keq);
      gs->SetJ2000Body(earth);
      gs->Initialize();
      if (sb->SetReceiveParticipantName("Groundstat") == false)
      {
         MessageInterface::ShowMessage("Failed to set the name of the receive "
               "participant\n");
         testResult = false;
      }

      if (sb->SetRefObject(gs, gs->GetType(), gs->GetName()) == false)
      {
         MessageInterface::ShowMessage("Failed to set the receive "
               "participant\n");
         testResult = false;
      }

      MessageInterface::ShowMessage("   Initializing\n");
      if (sb->Initialize())
      {
         MessageInterface::ShowMessage("   Modeling\n");
         if (sb->ModelSignal(21545.0) == false)
         {
            MessageInterface::ShowMessage("Geometric signal modeling failed\n");
            testResult = false;
         }
      }
      else
      {
         MessageInterface::ShowMessage("Geometric signal initialization "
               "failed\n");
         testResult = false;
      }

      MessageInterface::ShowMessage("   Deleting objects\n");
      delete sat;
      delete sat2;
      delete gs;
      delete sb;
      delete ss;
   }
   else
      testResult = false;

   reporter->Finalize();
   delete reporter;

   return testResult;
}

