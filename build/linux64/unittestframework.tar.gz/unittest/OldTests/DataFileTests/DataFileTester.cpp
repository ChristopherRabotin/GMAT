//$Id$
//------------------------------------------------------------------------------
//                           DataFileTester
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Feb 3, 2014
/**
 * 
 */
//------------------------------------------------------------------------------

#include "DataFileTester.hpp"
#include "TFSMagicNumbers.hpp"

// Specific classes used in the tests
#include "DataFile.hpp"
#include <iostream>

#ifdef CheckTDMRead
   #include "TdmObType.hpp"
#else
   #include "GmatObType.hpp"
#endif

// Classes needed to configure the test cases
#include "MessageInterface.hpp"


DataFileTester::DataFileTester()
{
}

DataFileTester::~DataFileTester()
{
}

bool DataFileTester::RunTests(SolarSystem *ss, ObjectArray *globals)
{
   bool testResult = true;

//   MessageInterface::ShowMessage("\nRunning Data File tests\n");


#ifndef CheckTDMRead
   DataFile *df = new DataFile("GmdDataFile");

   if (df)
   {
      MessageInterface::ShowMessage("\nBasic setup:  GmatObType\n");
      // Set file type
      
      GmatObType *got = new GmatObType();
      if (got)
      {
         df->SetStringParameter("Format", "GMATInternal");
         df->SetStringParameter("Filename", "Maui_GeometricRange.gmd");
         df->SetStream(got);
      
         MessageInterface::ShowMessage("\nDataFile Initialization\n");
         df->Initialize();
         
         MessageInterface::ShowMessage("\nOpening the file %s\n",
            df->GetStringParameter("Filename").c_str());
         df->OpenStream();
         
         // Read and report an observation
         MessageInterface::ShowMessage("\nReading the first observation\n");
         ObsData* od = df->ReadObservation();
         if (od)
         {
            MessageInterface::ShowMessage("   epoch:      %.12lf\n"
                                          "   Type:       %d\n"
                                          "   Type name:  %s\n"
                                          "   Participants:\n",
                                          od->epoch, od->type, od->typeName.c_str());  
            for (UnsignedInt i = 0; i < od->participantIDs.size(); ++i)
               MessageInterface::ShowMessage("      %s\n", od->participantIDs[i].c_str());                                     
            MessageInterface::ShowMessage("   %d strands:\n", od->strands.size());
            for (UnsignedInt i = 0; i < od->strands.size(); ++i)
            {
               MessageInterface::ShowMessage("      ");                                     
               for (UnsignedInt j = 0; j < od->strands[i].size(); ++j)
               {
                  if (j != 0)
                     MessageInterface::ShowMessage(", ");                                     
                  MessageInterface::ShowMessage("      %s\n", od->strands[i][j].c_str());                                     
               }
               MessageInterface::ShowMessage("\n");
            }
            MessageInterface::ShowMessage("   Units:      \"%s\"\n", od->units.c_str());
            MessageInterface::ShowMessage("   UniqueID:   %d\n", od->uniqueID);
            MessageInterface::ShowMessage("   %d data elements:\n", od->data.size());
            for (UnsignedInt i = 0; i < od->data.size(); ++i)
            {
               MessageInterface::ShowMessage("      ");
               if (od->dataMap.size() > i)
                  MessageInterface::ShowMessage("\"%s\"   ", od->dataMap[i].c_str());
               MessageInterface::ShowMessage("%.12lf\n", od->data[i]);
            }
         }
         else
         {
            MessageInterface::ShowMessage("   Read failed\n");
            testResult = false;
         }
         
         Integer obsCounter = 0;
         MessageInterface::ShowMessage("\nReading and counting the remaining observations\n");
         do
         {
            if (od)     // in case od was NULL on the first pass
               ++obsCounter;
            od = df->ReadObservation();
         } while (od != NULL);
         
         MessageInterface::ShowMessage("\nThe file contains %d observations\n", obsCounter);
         
         MessageInterface::ShowMessage("\nDataFile Finalization\n");
         df->Finalize();
      }
   }
   else
      testResult = false;
#endif
  
      
#ifdef CheckTDMRead
   // TdmObType test code
   // Signals should all process via SignalBase interfaces
   DataFile *df = new DataFile("TdmDataFile");
   bool ret = false;

   if(df)
   {
      MessageInterface::ShowMessage("\nBasic setup:  TdmObType\n\n");

      int i = 0;

      //Set file type
      TdmObType *tot = new TdmObType();

      std::string tdmFileName = "dsn17.txt";

      MessageInterface::ShowMessage("Testing file %s\n", tdmFileName.c_str());
      df->SetStringParameter("Filename", tdmFileName.c_str());
      df->SetStream(tot);

      ret = df->Initialize();

      if(ret)
         MessageInterface::ShowMessage("Step %d\n", ++i);

      ret = df->OpenStream();

      if(ret)
         MessageInterface::ShowMessage("Step %d\n", ++i);

      ObsData *od = df->ReadObservation();
      if (od)
      {
         TFSMagicNumbers *mnGenerator = TFSMagicNumbers::Instance();
         mnGenerator->FillMagicNumber(od);

         MessageInterface::ShowMessage("Step %d\n", ++i);

         ShowRecord(od);

         Integer obsCounter = 0;
         MessageInterface::ShowMessage("\nReading and counting the remaining observations\n");
         do
         {
            if (od)     // in case od was NULL on the first pass
               ++obsCounter;
            od = df->ReadObservation();
            if (od)
            {
               mnGenerator->FillMagicNumber(od);
               ShowRecord(od);
            }
         } while (od != NULL);
         
         MessageInterface::ShowMessage("\nThe file contains %d observations\n", obsCounter);
         df->Finalize();
      }
   }
   else
      testResult = false;

#endif

   return testResult;
}

void DataFileTester::ShowRecord(ObsData* od)
{
   MessageInterface::ShowMessage("Record at %p\n", od);
   MessageInterface::ShowMessage("   epoch:      %.12lf\n"
                                    "   Type:       %d\n"
                                    "   Type name:  %s\n"
                                    "   Participants:\n",
                                    od->epoch, od->type, od->typeName.c_str());
   for (UnsignedInt i = 0; i < od->participantIDs.size(); ++i)
         MessageInterface::ShowMessage("      %s\n", od->participantIDs[i].c_str());
   MessageInterface::ShowMessage("   %d strand(s):\n", od->strands.size());
   for (UnsignedInt i = 0; i < od->strands.size(); ++i)
   {
      MessageInterface::ShowMessage("      strand %d: ", i+1);
      for (UnsignedInt j = 0; j < od->strands[i].size(); ++j)
      {
         if (j != 0)
            MessageInterface::ShowMessage(", ");
         MessageInterface::ShowMessage("%s", od->strands[i][j].c_str());
      }
      MessageInterface::ShowMessage("\n");
   }
   MessageInterface::ShowMessage("   Units:      \"%s\"\n", od->units.c_str());

   MessageInterface::ShowMessage("   UniqueID:   %d\n", od->uniqueID);
   MessageInterface::ShowMessage("   %d data elements:\n", od->data.size());
   for (UnsignedInt i = 0; i < od->data.size(); ++i)
   {
      MessageInterface::ShowMessage("      ");
      if (od->dataMap.size() > i)
         MessageInterface::ShowMessage("\"%s\"   ", od->dataMap[i].c_str());
      MessageInterface::ShowMessage("%.12lf\n", od->data[i]);
   }
}
