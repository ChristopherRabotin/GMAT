//$Id$
//------------------------------------------------------------------------------
//                           MeasurementModelTester
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Feb 3, 2014
/**
 * 
 */
//------------------------------------------------------------------------------

#include "MeasurementModelTester.hpp"

// Specific classes used in the tests
#include "MeasureModel.hpp"
#include "ProgressReporter.hpp"

// Classes needed to configure the test cases
#include "Spacecraft.hpp"
#include "GroundStation.hpp"
#include "MessageInterface.hpp"


MeasurementModelTester::MeasurementModelTester()
{
}

MeasurementModelTester::~MeasurementModelTester()
{
}

bool MeasurementModelTester::RunTests(SolarSystem* ss, ObjectArray* globals)
{
   bool testResult = true;

   MessageInterface::ShowMessage("\nRunning Measurement Model tests\n");
   CelestialBody *earth = ss->GetBody("Earth");

   // Signals should all process via SignalBase interfaces
   MeasureModel *mm = new MeasureModel("TestModel");

   ProgressReporter *reporter = new ProgressReporter(
         "Unit Tests for the MeasurementModel class\nTesting the reporter\n"
         "***************************************************************",
         "../output/MeasurementModelTester.txt");
   mm->SetProgressReporter(reporter);
   reporter->SetLogLevel("Verbose", "Measurement");
   reporter->SetLogLevel("Everything", "Signal");
   reporter->SetLogLevel("Everything", "Measurement");
//   reporter->SetLogLevel("Verbose", "Signal");

   reporter->Flush();

   reporter->Initialize();

   if (mm)
   {
      mm->SetProgressReporter(reporter);
      mm->SetSolarSystem(ss);

      mm->SetStringParameter("SignalPath", "GStation, Sat, GStation");
      mm->SetStringParameter("SignalPath", "GStation, Sat, Sat2, Sat, GStation");

      StringArray refObjects = mm->GetRefObjectNameArray(Gmat::UNKNOWN_OBJECT);
      MessageInterface::ShowMessage("SignalPath has %d unique references\n",
            refObjects.size());
      for (UnsignedInt i = 0; i < refObjects.size(); ++i)
      {
         MessageInterface::ShowMessage("   %s\n", refObjects[i].c_str());
      }

      // Test initialization: objects not yet passed in
      try
      {
         mm->Initialize();
         mm->CalculateMeasurement();
      }
      catch (BaseException &e)
      {
         MessageInterface::ShowMessage("Correctly handled no-objects "
               "exception:\n   %s\n", e.GetFullMessage().c_str());
      }

      // Build, configure, and pass in the participants
      CoordinateSystem *j2keq = ((CoordinateSystem*)(globals->at(0)));
      CoordinateSystem *ef = ((CoordinateSystem*)(globals->at(2)));

      Spacecraft *sat   = new Spacecraft("Sat");
      sat->SetSolarSystem(ss);
      sat->SetJ2000Body(earth);
      sat->SetInternalCoordSystem(j2keq);
      sat->SetRefObject(j2keq, j2keq->GetType(), j2keq->GetName());
      sat->SetRefObject(ef, ef->GetType(), ef->GetName());
      sat->Initialize();

      Spacecraft *sat2   = new Spacecraft("Sat2");
      sat2->SetSolarSystem(ss);
      sat2->SetJ2000Body(earth);
      sat2->SetInternalCoordSystem(j2keq);
      sat2->SetRefObject(j2keq, j2keq->GetType(), j2keq->GetName());
      sat2->SetRefObject(ef, ef->GetType(), ef->GetName());
      sat2->SetRealParameter("X", sat->GetRealParameter("X") + 300);
      sat2->SetRealParameter("VX", sat->GetRealParameter("VX") + 0.5);
      sat2->Initialize();

      GroundStation *gs = new GroundStation("GStation");
      gs->SetSolarSystem(ss);
      gs->SetInternalCoordSystem(j2keq);
      gs->SetJ2000Body(earth);
      gs->Initialize();

      mm->SetRefObject(sat, sat->GetType(), sat->GetName());
      if (mm->SetRefObject(sat2, sat2->GetType(), sat2->GetName()) == false)
         MessageInterface::ShowMessage("   Correctly ignoring %s\n",
               sat2->GetName().c_str());
      mm->SetRefObject(gs, gs->GetType(), gs->GetName());

      if (mm->Initialize())
      {
         mm->CalculateMeasurement();
      }

      delete mm;
   }

   reporter->Finalize();
   delete reporter;

   return testResult;
}
