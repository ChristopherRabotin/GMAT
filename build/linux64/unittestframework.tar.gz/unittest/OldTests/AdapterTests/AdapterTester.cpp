//$Id$
//------------------------------------------------------------------------------
//                           AdapterTester
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Feb 3, 2014
/**
 * Unit test code for the tracking data adapters
 */
//------------------------------------------------------------------------------

#include "AdapterTester.hpp"

// Specific classes used in the tests
#include "MeasureModel.hpp"
#include "TrackingDataAdapter.hpp"
#include "ProgressReporter.hpp"
#include "RangeAdapterKm.hpp"

// Classes needed to configure the test cases
#include "Spacecraft.hpp"
#include "GroundStation.hpp"
#include "MessageInterface.hpp"


//------------------------------------------------------------------------------
// AdapterTester::AdapterTester()
//------------------------------------------------------------------------------
/**
 * Constructor
 */
//------------------------------------------------------------------------------
AdapterTester::AdapterTester()
{
}

//------------------------------------------------------------------------------
// AdapterTester::~AdapterTester()
//------------------------------------------------------------------------------
/**
 * Destructor
 */
//------------------------------------------------------------------------------
AdapterTester::~AdapterTester()
{
}

//------------------------------------------------------------------------------
// bool AdapterTester::RunTests(SolarSystem* ss, ObjectArray* globals)
//------------------------------------------------------------------------------
/**
 * Runner for the tests
 *
 * @param ss The solar system
 * @param globals Array of globally visible objects -- basically the default
 *                coordinate systems
 *
 * @return
 */
//------------------------------------------------------------------------------
bool AdapterTester::RunTests(SolarSystem* ss, ObjectArray* globals)
{
   bool testResult = false;
   std::vector<bool> results;

   MessageInterface::ShowMessage("\nRunning Range Adapter tests\n");
   CelestialBody *earth = ss->GetBody("Earth");

   ProgressReporter *reporter = new ProgressReporter(
         "Unit Tests for the RangeAdapterKm class\nTesting the reporter\n"
         "***************************************************************",
         "../output/AdapterTester.txt");

   reporter->SetLogLevel("Everything", "Adapter");
   reporter->SetLogLevel("Verbose", "Measurement");
   reporter->SetLogLevel("Everything", "Signal");
   reporter->SetLogLevel("Everything", "Measurement");

   reporter->Flush();
   reporter->Initialize();

   // Here I'm mimicking the TrackingFileSet Initialize method
   RangeAdapterKm *rak = new RangeAdapterKm("KmRange");
   MeasureModel   *mm  = new MeasureModel("RangeMeasurement");

   if (rak && mm)
   {
      rak->SetProgressReporter(reporter);
      rak->SetSolarSystem(ss);
      rak->SetMeasurement(mm);

//      rak->SetStringParameter("SignalPath", "GStation, Sat, GStation");
//      rak->SetStringParameter("SignalPath", "GStation, Sat, Sat2, Sat, "
//            "GStation");
      rak->SetStringParameter("SignalPath", "Sat, GStation");
      rak->SetStringParameter("SignalPath", "GStation, Sat");
      rak->SetStringParameter("SignalPath", "GStation, Sat, Sat2");

      StringArray refObjects = rak->GetRefObjectNameArray(Gmat::UNKNOWN_OBJECT);

      #ifdef SHOW_DETAILS
         MessageInterface::ShowMessage("RangeAdapter has %d unique references\n",
               refObjects.size());
         for (UnsignedInt i = 0; i < refObjects.size(); ++i)
         {
            MessageInterface::ShowMessage("   %s\n", refObjects[i].c_str());
         }
      #endif
      
      // Test initialization: objects not yet passed in
      try
      {
         if (rak->Initialize())
            rak->CalculateMeasurement();

         testResult = false;
      }
      catch (BaseException &e)
      {
         MessageInterface::ShowMessage("Correctly handled no-objects "
               "exception:\n   %s\n", e.GetFullMessage().c_str());

         results.push_back(true);
      }

      // Build, configure, and pass in the participants
      CoordinateSystem *j2keq = ((CoordinateSystem*)(globals->at(0)));
      CoordinateSystem *ef = ((CoordinateSystem*)(globals->at(2)));

      Spacecraft *sat   = new Spacecraft("Sat");
      sat->SetSolarSystem(ss);
      sat->SetJ2000Body(earth);
      sat->SetInternalCoordSystem(j2keq);
      sat->SetRefObject(j2keq, j2keq->GetType(), j2keq->GetName());
      sat->SetRefObject(ef, ef->GetType(), ef->GetName());
      sat->Initialize();

      Spacecraft *sat2   = new Spacecraft("Sat2");
      sat2->SetSolarSystem(ss);
      sat2->SetJ2000Body(earth);
      sat2->SetInternalCoordSystem(j2keq);
      sat2->SetRefObject(j2keq, j2keq->GetType(), j2keq->GetName());
      sat2->SetRefObject(ef, ef->GetType(), ef->GetName());
      sat2->SetRealParameter("X", sat->GetRealParameter("X") + 300);
      sat2->SetRealParameter("VX", sat->GetRealParameter("VX") + 0.5);
      sat2->SetRealParameter("Y", sat->GetRealParameter("Y") - 100);
      sat2->SetRealParameter("VY", sat->GetRealParameter("VY") - 0.9);
      sat2->Initialize();

      GroundStation *gs = new GroundStation("GStation");
      gs->SetSolarSystem(ss);
      gs->SetInternalCoordSystem(j2keq);
      gs->SetJ2000Body(earth);
      gs->Initialize();

      try
      {
         rak->SetRefObject(sat, sat->GetType(), sat->GetName());
         if (rak->SetRefObject(sat2, sat2->GetType(), sat2->GetName()) == false)
            MessageInterface::ShowMessage("   Correctly ignoring %s\n",
                  sat2->GetName().c_str());
         rak->SetRefObject(gs, gs->GetType(), gs->GetName());

         if (rak->Initialize())
         {
            // Initialization complete; this piece tests the computation
            MeasurementData data = rak->CalculateMeasurement();

            MessageInterface::ShowMessage("Measurement calculated; data:\n   "
                  "Epoch %.12lf\n   Signal path ranges: [", data.epoch);
            for (UnsignedInt i = 0; i < data.value.size(); ++i)
            {
               if (i > 0)
                  MessageInterface::ShowMessage(", ");
               MessageInterface::ShowMessage("%15.10lf", data.value[i]);
            }
            MessageInterface::ShowMessage("]\n");

            results.push_back(true);

            Integer id = 250 * sat->GetType() +
                  sat->GetParameterID("CartesianState");
            std::vector<RealArray> dv =
                  rak->CalculateMeasurementDerivatives(sat, id);

            MessageInterface::ShowMessage("Measurement derivative calculated "
                  "w.r.t. sat.CartesianState; data:\n"
                  "   Epoch %.12lf\n", data.epoch);
            for (UnsignedInt h = 0; h < dv.size(); ++h)
            {
               for (UnsignedInt i = 0; i < dv[h].size(); ++i)
               {
                  if (i > 0)
                     MessageInterface::ShowMessage(", ");
                  else
                     MessageInterface::ShowMessage("   [");
                  MessageInterface::ShowMessage("%.12lf", dv[h][i]);
               }
               MessageInterface::ShowMessage("]\n");
            }
            results.push_back(true);
         }
         else results.push_back(false);
      }
      catch (BaseException &ex)
      {
         MessageInterface::ShowMessage("Exception in Adapter tests:\n  %s\n",
               ex.GetDetails().c_str());
         results.push_back(false);
      }

      delete rak;
   }

   reporter->Finalize();
   delete reporter;

   testResult = results[0];
   for (UnsignedInt i = 1; i < results.size(); ++i)
      testResult = testResult && results[i];

   return testResult;
}
