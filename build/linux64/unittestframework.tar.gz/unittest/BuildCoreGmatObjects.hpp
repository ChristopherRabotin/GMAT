//$Id$
//------------------------------------------------------------------------------
//                           BuildCoreGmatObjects
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Jan 22, 2014
/**
 * Functions used to build, initialize, and delete GMAT basic objects
 */
//------------------------------------------------------------------------------

#ifndef BUILDCOREGMATOBJECTS_HPP_
#define BUILDCOREGMATOBJECTS_HPP_

#include "gmatdefs.hpp"

#include "SolarSystem.hpp"
#include "CoordinateSystem.hpp"
#include "GmatGlobal.hpp"


GmatGlobal * SetGmatGlobals();
SolarSystem* BuildSolarSystem();
ObjectArray* BuildCoordinateSystems(SolarSystem *ss);

CoordinateSystem* CreateCoordinateSystem(const std::string &name,
      bool createDefault, SolarSystem *ss);
AxisSystem* CreateAxisSystem(const std::string &type, const std::string &name);

#endif /* BUILDCOREGMATOBJECTS_HPP_ */
