//$Id$
//------------------------------------------------------------------------------
//                           BuildCoreGmatObjects
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Jan 22, 2014
/**
 * 
 */
//------------------------------------------------------------------------------

#include "BuildCoreGmatObjects.hpp"
#include "SolarSystem.hpp"
#include "CoordinateSystem.hpp"
#include "AxisSystem.hpp"
#include "BodyFixedAxes.hpp"
#include "ICRFAxes.hpp"
#include "AxisSystemFactory.hpp"

#include "EopFile.hpp"
#include "ItrfCoefficientsFile.hpp"
#include "LeapSecsFileReader.hpp"
#include "TimeSystemConverter.hpp"
#include "MessageInterface.hpp"



//------------------------------------------------------------------------------
// GmatGlobal * SetGmatGlobals()
//------------------------------------------------------------------------------
/**
 * Sets up global structures used for other objects
 *
 * @return A pointer to the GmatGlobal singleton
 */
//------------------------------------------------------------------------------
GmatGlobal * SetGmatGlobals()
{
   static bool globalsSet = false;
   GmatGlobal *gg = NULL;

   // Ensure that this stuff is only done once
   if (globalsSet == false)
   {
      gg = GmatGlobal::Instance();

      // Coordinate system construction needs these
      // File paths, assuning running from the GMAT bin folder
      std::string eopfilename = "../data/planetary_coeff/eopc04_08.62-now";
      std::string nutFileName = "../data/planetary_coeff/NUTATION.DAT";
      std::string planFileName = "../data/planetary_coeff/NUT85.DAT";
      std::string leapSecFileName = "../data/time/tai-utc.dat";

      EopFile *theEopFile = new EopFile(eopfilename);
      theEopFile->Initialize();
      ItrfCoefficientsFile *theItrfFile =
            new ItrfCoefficientsFile(nutFileName, planFileName);
      theItrfFile->Initialize();
      LeapSecsFileReader *theLeapSecsFileReader =
            new LeapSecsFileReader(leapSecFileName);
      theLeapSecsFileReader->Initialize();

      gg->SetEopFile(theEopFile);
      gg->SetItrfCoefficientsFile(theItrfFile);

      TimeConverterUtil::SetEopFile(theEopFile);
      TimeConverterUtil::SetLeapSecsFileReader(theLeapSecsFileReader);

      // Singleton set, so set the flag
      globalsSet = true;
   }

   return gg;
}


//------------------------------------------------------------------------------
// SolarSystem* BuildSolarSystem()
//------------------------------------------------------------------------------
/**
 * Constructs and initializes the solar system used in the tests
 *
 * @return The solar system
 */
//------------------------------------------------------------------------------
SolarSystem* BuildSolarSystem()
{
   SolarSystem *ss = new SolarSystem();
   ss->Initialize();
   return ss;
}


//------------------------------------------------------------------------------
// ObjectArray* BuildCoordinateSystems(SolarSystem *ss)
//------------------------------------------------------------------------------
/**
 * Creates teh set of default coordinate systems that GMAT objects might need
 *
 * @param ss The solar ssyem used in the tests
 *
 * @return An ObjectArray containint the coordinate systems
 */
//------------------------------------------------------------------------------
ObjectArray* BuildCoordinateSystems(SolarSystem *ss)
{
   ObjectArray *csSet = new ObjectArray;

   try
   {
      GmatGlobal *gg = GmatGlobal::Instance();
      SpacePoint *earth = (SpacePoint*)ss->GetBody("Earth");
      CoordinateSystem *cs;

      EopFile *theEopFile = gg->GetEopFile();
      ItrfCoefficientsFile *theItrfFile = gg->GetItrfCoefficientsFile();

      // EarthMJ2000Eq
      cs = CreateCoordinateSystem("EarthMJ2000Eq", true, ss);
      csSet->push_back(cs);

      // EarthMJ2000Ec
      cs = CreateCoordinateSystem("EarthMJ2000Ec", false, ss);
      AxisSystem *ecAxis = CreateAxisSystem("MJ2000Ec", "MJ2000Ec_Earth");
      ecAxis->SetOrigin(earth);
      ecAxis->SetJ2000Body(earth);

      // Set required internal references if they are used
      if (ecAxis->UsesEopFile() == GmatCoordinate::REQUIRED)
         ecAxis->SetEopFile(theEopFile);
      if (ecAxis->UsesItrfFile() == GmatCoordinate::REQUIRED)
         ecAxis->SetCoefficientsFile(theItrfFile);

      cs->SetStringParameter("Origin", "Earth");
      cs->SetJ2000BodyName("Earth");
      cs->SetRefObject(ecAxis, Gmat::AXIS_SYSTEM, ecAxis->GetName());
      cs->SetOrigin(earth);
      cs->SetJ2000Body(earth);
      cs->SetSolarSystem(ss);
      cs->Initialize();
      csSet->push_back(cs);
      delete ecAxis;

      // EarthFixed
      cs = CreateCoordinateSystem("EarthFixed", false, ss);
      BodyFixedAxes *bfecAxis =
            (BodyFixedAxes*)CreateAxisSystem("BodyFixed", "BodyFixed_Earth");
      bfecAxis->SetOrigin(earth);
      bfecAxis->SetJ2000Body(earth);
      // Set required internal references if they are used
      if (bfecAxis->UsesEopFile() == GmatCoordinate::REQUIRED)
         bfecAxis->SetEopFile(theEopFile);
      if (bfecAxis->UsesItrfFile() == GmatCoordinate::REQUIRED)
         bfecAxis->SetCoefficientsFile(theItrfFile);

      cs->SetStringParameter("Origin", "Earth");
      cs->SetJ2000BodyName("Earth");
      cs->SetRefObject(bfecAxis, Gmat::AXIS_SYSTEM, bfecAxis->GetName());
      cs->SetOrigin(earth);
      cs->SetJ2000Body(earth);
      cs->SetSolarSystem(ss);
//      cs->SetEopFile(theEopFile);
//      cs->SetCoefficientsFile(theItrfFile);
      cs->Initialize();
      csSet->push_back(cs);
      delete bfecAxis;

      // EarthICRF
      cs = CreateCoordinateSystem("EarthICRF", false, ss);
      ICRFAxes *icrfAxis =
         (ICRFAxes*)CreateAxisSystem("ICRF", "ICRF_Axis");
      icrfAxis->SetOrigin(earth);
      icrfAxis->SetJ2000Body(earth);

      // Set required internal references if they are used
      if (icrfAxis->UsesEopFile() == GmatCoordinate::REQUIRED)
         icrfAxis->SetEopFile(theEopFile);
      if (icrfAxis->UsesItrfFile() == GmatCoordinate::REQUIRED)
         icrfAxis->SetCoefficientsFile(theItrfFile);

      cs->SetStringParameter("Origin", "Earth");
      cs->SetJ2000BodyName("Earth");
      cs->SetRefObject(icrfAxis, Gmat::AXIS_SYSTEM, icrfAxis->GetName());
      cs->SetOrigin(earth);
      cs->SetJ2000Body(earth);
      cs->SetSolarSystem(ss);
      cs->Initialize();
      csSet->push_back(cs);
      delete icrfAxis;


      // Mark these as built-in coordinate systems
      for (ObjectArray::iterator i = csSet->begin(); i != csSet->end(); ++i)
      {
         ((CoordinateSystem*)(*i))->SetIsBuiltIn(true);
      }
   }
   catch (BaseException &e)
   {
      MessageInterface::ShowMessage
         ("BuildCoordSystems() Error occurred during default "
          "coordinate system creation. " +  e.GetFullMessage());
   }

   return csSet;
}


//------------------------------------------------------------------------------
// CoordinateSystem* CreateCoordinateSystem(const std::string &name,
//       bool createDefault, SolarSystem *ss)
//------------------------------------------------------------------------------
/**
 * Method (adapted from the Moderator) to create a coordinate system
 *
 * @param name The name of the CS
 * @param createDefault true if the axis system should be created and attached,
 *        false if not
 * @param ss The solar system used in the tests
 *
 * @return The new coordinate system
 */
//------------------------------------------------------------------------------
CoordinateSystem* CreateCoordinateSystem(const std::string &name,
      bool createDefault, SolarSystem *ss)
{
   CoordinateSystem *obj;
   obj = new CoordinateSystem(name, name);

   try
   {
      CelestialBody *earth = ss->GetBody("Earth");

      // Set J2000Body and SolarSystem
      obj->SetJ2000BodyName("Earth");
      obj->SetRefObject(earth, Gmat::SPACE_POINT, "Earth");
      obj->SetSolarSystem(ss);
      obj->Initialize();

      if (createDefault)
      {
         // create MJ2000Eq AxisSystem with Earth as origin
         AxisSystem *axis = CreateAxisSystem("MJ2000Eq", "MJ2000Eq_Earth");
         axis->SetOrigin(earth);
         axis->SetJ2000Body(earth);
         obj->SetJ2000BodyName("Earth");
         obj->SetStringParameter("Origin", "Earth");
         obj->SetRefObject(earth, Gmat::SPACE_POINT, "Earth");
         obj->SetRefObject(axis, Gmat::AXIS_SYSTEM, axis->GetName());
         obj->SetSolarSystem(ss);
         obj->Initialize();
         delete axis;
      }
   }
   catch (BaseException &)
   {
      throw;
   }

   return obj;
}


//------------------------------------------------------------------------------
// AxisSystem* CreateAxisSystem(const std::string &type,
//       const std::string &name)
//------------------------------------------------------------------------------
/**
 * Creates an axis system
 *
 * @param type The axis type
 * @param name The name of the axis system
 *
 * @return A new, uninitialized axis system of the specified type
 */
//------------------------------------------------------------------------------
AxisSystem* CreateAxisSystem(const std::string &type, const std::string &name)
{
   AxisSystemFactory asf;
   AxisSystem *axisSystem = asf.CreateAxisSystem(type, name);

   if (axisSystem == NULL)
   {
      MessageInterface::ShowMessage
         ("ERROR: Cannot create a AxisSystem type: %s.\n"
          "Make sure %s is correct type and registered to AxisSystemFactory.\n",
          type.c_str(), type.c_str());

      return NULL;
   }

   return axisSystem;
}
