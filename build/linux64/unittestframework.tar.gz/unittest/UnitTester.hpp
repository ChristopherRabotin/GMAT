//$Id$
//------------------------------------------------------------------------------
//                           UnitTester
//------------------------------------------------------------------------------
// GMAT: General Mission Analysis Tool
//
// Copyright (c) 2002-2011 United States Government as represented by the
// Administrator of The National Aeronautics and Space Administration.
// All Other Rights Reserved.
//
// Developed jointly by NASA/GSFC and Thinking Systems, Inc. under the FDSS 
// contract, Task Order 28
//
// Author: Darrel J. Conway, Thinking Systems, Inc.
// Created: Feb 3, 2014
/**
 * 
 */
//------------------------------------------------------------------------------

#ifndef UNITTESTER_HPP_
#define UNITTESTER_HPP_

#include "gmatdefs.hpp"

class SolarSystem;


class UnitTester
{
public:
   UnitTester();
   virtual ~UnitTester();

   virtual bool RunTests(SolarSystem *ss = NULL,
         ObjectArray *globals = NULL) = 0;

private:
   UnitTester(const UnitTester&);
   UnitTester& operator=(const UnitTester&);
};

#endif /* UNITTESTER_HPP_ */
